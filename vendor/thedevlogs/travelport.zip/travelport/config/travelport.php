<?php
return [
    'TARGETBRANCH' => '',
    'CREDENTIALS' => '',
    'PROVIDER' => '',
    'DEBUG' => FALSE,
    'USER' => 'admin',
];
